<?php $__env->startSection('title', 'Dashboard - Gestión de Préstamos'); ?>

<?php $__env->startSection('content'); ?>
<div class="mb-6 flex justify-end">
    <button id="start-tour" class="bg-purple-600 text-white px-4 py-2 rounded hover:bg-purple-700">
        📖 Iniciar Tutorial
    </button>
</div>

<div class="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
    <!-- Panel de Herramientas Disponibles -->
    <div id="herramientas-panel" class="bg-white rounded-lg shadow-lg p-6">
        <h2 class="text-xl font-bold mb-4 text-gray-800">🔧 Herramientas Disponibles</h2>
        <div id="herramientas-disponibles" class="space-y-2 min-h-[200px]">
            <?php $__empty_1 = true; $__currentLoopData = $herramientas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $herramienta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="herramienta-item bg-blue-50 border border-blue-200 p-3 rounded cursor-move hover:shadow-md transition"
                     data-id="<?php echo e($herramienta->id); ?>">
                    <div class="font-semibold"><?php echo e($herramienta->nombre); ?></div>
                    <div class="text-sm text-gray-600">Código: <?php echo e($herramienta->codigo); ?></div>
                    <?php if($herramienta->categoria): ?>
                        <div class="text-xs text-gray-500"><?php echo e($herramienta->categoria); ?></div>
                    <?php endif; ?>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-gray-500 text-center py-8">
                    No hay herramientas disponibles
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Panel de Técnicos -->
    <div id="tecnicos-panel" class="bg-white rounded-lg shadow-lg p-6">
        <h2 class="text-xl font-bold mb-4 text-gray-800">👤 Técnicos Activos</h2>
        <div class="space-y-2">
            <?php $__empty_1 = true; $__currentLoopData = $tecnicos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tecnico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="tecnico-zone bg-green-50 border-2 border-dashed border-green-300 p-4 rounded min-h-[80px]"
                     data-tecnico-id="<?php echo e($tecnico->id); ?>">
                    <div class="font-semibold text-gray-800"><?php echo e($tecnico->nombre_completo); ?></div>
                    <div class="text-sm text-gray-600"><?php echo e($tecnico->email); ?></div>
                    <?php if($tecnico->departamento): ?>
                        <div class="text-xs text-gray-500"><?php echo e($tecnico->departamento); ?></div>
                    <?php endif; ?>
                    <div class="herramientas-asignadas mt-2 space-y-1"></div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="text-gray-500 text-center py-8">
                    No hay técnicos activos
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Tabla de Préstamos Activos -->
<div id="prestamos-activos" class="bg-white rounded-lg shadow-lg p-6">
    <h2 class="text-xl font-bold mb-4 text-gray-800">📋 Préstamos Activos</h2>
    <div class="overflow-x-auto">
        <table class="min-w-full">
            <thead class="bg-gray-50">
                <tr>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Técnico</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Herramienta</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha Préstamo</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Notas</th>
                    <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Acciones</th>
                </tr>
            </thead>
            <tbody id="prestamos-list" class="divide-y divide-gray-200">
                <?php $__empty_1 = true; $__currentLoopData = $prestamos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prestamo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr data-prestamo-id="<?php echo e($prestamo->id); ?>">
                        <td class="px-6 py-4"><?php echo e($prestamo->tecnico->nombre_completo); ?></td>
                        <td class="px-6 py-4"><?php echo e($prestamo->herramienta->nombre); ?></td>
                        <td class="px-6 py-4"><?php echo e($prestamo->fecha_prestamo->format('d/m/Y H:i')); ?></td>
                        <td class="px-6 py-4"><?php echo e($prestamo->notas ?? '-'); ?></td>
                        <td class="px-6 py-4">
                            <button onclick="devolverHerramienta(<?php echo e($prestamo->id); ?>)" 
                                    class="bg-green-600 text-white px-3 py-1 rounded text-sm hover:bg-green-700">
                                Devolver
                            </button>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="5" class="px-6 py-4 text-center text-gray-500">
                            No hay préstamos activos
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/red/Desktop/Prestamos-Tool/resources/views/prestamos/index.blade.php ENDPATH**/ ?>